//
//  View.h
//  Japan
//
//  Created by NYU User on 10/21/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface View: UIView {
}

@end
