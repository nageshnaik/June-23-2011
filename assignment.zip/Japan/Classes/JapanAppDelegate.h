//
//  JapanAppDelegate.h
//  Japan
//
//  Created by NYU User on 10/21/10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
@class View;

@interface JapanAppDelegate: NSObject <UIApplicationDelegate> {
	View *view;
	UIWindow *window;
}

//@property (nonatomic, retain) IBOutlet UIWindow *window;
@end

